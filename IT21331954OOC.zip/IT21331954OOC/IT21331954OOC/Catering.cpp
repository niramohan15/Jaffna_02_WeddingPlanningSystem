#include "Catering.h"
using namespace std;
Catering::Catering()
{
	cId = 000;
}
Catering::Catering(int Id)
{
	cId = Id;

}

