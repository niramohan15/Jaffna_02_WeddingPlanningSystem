#include "Photography.h"
using namespace std;

Photography::Photography()
{
	pId = 000;
}

Photography::Photography(int Id)
{
	pId = Id;

}

