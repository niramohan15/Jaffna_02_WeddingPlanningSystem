#include "HallDealer.h"
using namespace std;

HallDealer::HallDealer(int Id)
{
	hId = Id;

}

HallDealer::HallDealer()
{
	hId = 000;
}
